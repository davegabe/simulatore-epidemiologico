public class Manager {
    public int duration;
    public int infectivity;
    public int symptomaticity;
    private int resources;
    private float swabCost;
    private float speed;
    public Person[] people = new Person[5];

    public static void main(String[] args) {
        new GUI().initialize();
    }

}

import java.awt.*;

public class Physics {
    int x1, x2, y1, y2;
    Manager manager;

    Physics(Manager manager, int x1, int x2, int y1, int y2) {
        this.manager = manager;
        this.x1 = x1;
        this.x2 = x2;
        this.y1 = y1;
        this.y2 = y2;
    }
/*
    public void collisionDetection() {
        //create the quadTree
        QuadTree quadTree = new QuadTree(x1, x2, y1, y2);
        for (int i = 0; i < manager.people.length; i++) {
            quadTree.insert(manager.people[i]);
        }
        //
        findNearPlayers(quadTree);
    }

    private void findNearPlayers(QuadTree quadtree) {
        if (quadtree.children == null) {   //if is a leaf check collisions
            checkCollision();
        } else {
            for (int i = 0; i < 4; i++) {   //if isn't a leaf, go deeper
                findNearPlayers(quadtree.children[i]);
            }
        }
    }

    private void checkCollision() {
        for (int i = 0; i < manager.people.length; i++) {
            manager.people[i].movePlayer();
            //check with other players
            for (int j = i + 1; j < manager.people.length; j++) {
                double distance = Math.sqrt(Math.pow(manager.people[i].x - manager.people[j].x, 2) + Math.pow(manager.people[i].y - manager.people[j].y, 2));
                if (distance <= Person.r * 2) {
                    manager.people[i].onCollisionEnter(manager.people[j]);
                    manager.people[j].onCollisionEnter(manager.people[i]);

                    manager.people[i].moveBackPlayer();
                    manager.people[i].moveBackPlayer();
                    int invertedAnglei = manager.people[i].dir.getInvertedAngle();
                    int invertedAnglej = manager.people[j].dir.getInvertedAngle();
                    manager.people[i].dir.randomDirection(invertedAnglej);
                    manager.people[j].dir.randomDirection(invertedAnglei);
                    manager.people[i].movePlayer();
                }
            }
            //check with walls
            for (int j = 0; j < 4; j++) {
                Point upper = new Point(manager.people[i].x, manager.people[i].y + Person.r);
                Point bottom = new Point(manager.people[i].x, manager.people[i].y - Person.r);
                Point left = new Point(manager.people[i].x - Person.r, manager.people[i].y);
                Point right = new Point(manager.people[i].x + Person.r, manager.people[i].y);
                if (manager.walls[j].contains(upper) || manager.walls[j].contains(bottom) || manager.walls[j].contains(left) || manager.walls[j].contains(right)) {
                    manager.people[i].moveBackPlayer();
                    manager.people[i].moveBackPlayer();
                    manager.people[i].dir.randomDirection(manager.walls[j].dir.angle);
                    manager.people[i].movePlayer();
                }
            }
        }
    }
*/
}

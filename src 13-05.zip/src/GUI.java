import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;

import static javax.swing.SwingConstants.HORIZONTAL;

public class GUI extends JPanel {

    static int popolazione = 1;
    static int tamp = 1;
    static int incontri = 1;
    private final Color yellow = new Color(233, 196, 106);
    private final Color green = new Color(42, 157, 143);
    private final Color red = new Color(231, 111, 81);
    private final Color blue = new Color(45, 143, 171);
    private final Color black = new Color(26, 24, 27);
    private final Color gunmetal = new Color(19, 39, 53);
    private GridBagConstraints c;
    private JTextField popolazione_txtfield;
    private JTextField tamp_txtfield;
    private JTextField incontri_txtfield;
    private JTextField risorse_txtfield;
    private JSlider inf_slider;
    private JSlider let_slider;
    private JSlider sint_slider;
    private JSlider durata_slider;

    GUI() {

    }

    public void initialize() {
        JFrame f = new JFrame("COVID-2027 GVNG");
        f.setSize(1500, 900);
        f.setLayout(new BorderLayout());
        f.getContentPane().setBackground(gunmetal); //gunmetal
        //f.setResizable(false);

        createLeftPanel(f, green);
        createRightPanel(f, green);
        createCenterPanel(f, gunmetal, green, yellow, red, blue, black);

        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        f.setVisible(true);
    }

    private void createLeftPanel(JFrame f, Color color) {
        JPanel left_p = new JPanel(); // this is the big left panel
        left_p.setBackground(color);         //set color of the panel
        left_p.setLayout(new BoxLayout(left_p, BoxLayout.Y_AXIS));
        f.add(left_p, BorderLayout.WEST);
        c = new GridBagConstraints();

        // INSERIMENTO POPOLAZIONE FIELD
        popolazione_txtfield = createTextField("Popolazione", left_p);
        // INSERIMENTO TAMPONE FIELD
        tamp_txtfield = createTextField("Costo tampone", left_p);
        // INSERIMENTO INCONTRI FIELD
        incontri_txtfield = createTextField("Incontri", left_p);
        // INSERIMENTO RISORSE FIELD
        risorse_txtfield = createTextField("Risorse", left_p);

        //
        left_p.add(Box.createRigidArea(new Dimension(0, 120)));   // SPAZIO CHE DIVIDE SLIDER DA BOTTONI
        /*BufferedImage myPicture = ImageIO.read(new File("/Users/beatrice/IdeaProjects/covid-2027GVNG/src"));
        JLabel picLabel = new JLabel(new ImageIcon(myPicture));
        left_p.add(picLabel);

        File img = new File("/Users/beatrice/IdeaProjects/covid-2027GVNG/src");
        JLabel imgLabel = new JLabel(new ImageIcon(img.getName()));
        left_p.add(imgLabel);*/

        JLabel img = new JLabel("IMAGE GOES HERE");
        img.setFont(new Font("Times New Roman", Font.PLAIN, 25));
        left_p.add(img);

        popolazione_txtfield.addKeyListener(new NumbersOnlyInput(popolazione_txtfield, false));
        tamp_txtfield.addKeyListener(new NumbersOnlyInput(tamp_txtfield, false));
        incontri_txtfield.addKeyListener(new NumbersOnlyInput(incontri_txtfield, true));
        risorse_txtfield.addKeyListener(new NumbersOnlyInput(risorse_txtfield, true));
    }

    private JTextField createTextField(String label, JPanel parentPanel) {
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new GridBagLayout());
        c.fill = GridBagConstraints.HORIZONTAL;
        parentPanel.add(jPanel);

        JLabel jLabel = new JLabel();
        jLabel.setText(label);
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(0, 30, 0, 0);
        jPanel.add(jLabel, c);


        JTextField jTextField = new JTextField("");
        jTextField.setPreferredSize(new Dimension(200, 24));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 1;
        c.insets = new Insets(8, 40, 0, 30);         // inserisce uno spazio tra gli elementi
        jPanel.add(jTextField, c);
        return jTextField;
        // http://www.davismol.net/2014/12/18/java-swing-un-esempio-di-utilizzo-del-gridbaglayout-per-la-realizzazione-di-un-form/
    }

    private void createRightPanel(JFrame f, Color color) {
        JPanel right_p = new JPanel(); // this is the big left panel
        right_p.setBackground(color);         //set color of the panel
        right_p.setLayout(new BoxLayout(right_p, BoxLayout.Y_AXIS));
        f.add(right_p, BorderLayout.EAST);

        // INSERIMENTO SLIDER INFETTIVITÁ
        inf_slider = createSlider("          Infettività", right_p, yellow, 10, 20, 100);
        // INSERIMENTO SLIDER SINTOMATICITÀ
        sint_slider = createSlider("          Sintomaticità", right_p, red, 10, 20, 100);
        // INSERIMENTO SLIDER LETALITÀ
        let_slider = createSlider("          Letalità", right_p, black, 10, 20, 100);
        // INSERIMENTO SLIDER DURATA
        durata_slider = createSlider("          Durata", right_p, gunmetal, 5, 15, 45);

        right_p.add(Box.createRigidArea(new Dimension(0, 120)));   // SPAZIO CHE DIVIDE SLIDER DA BOTTONI

        JPanel play_p = new JPanel();


        play_p.setBackground(color);
        JButton play = new JButton("PLAY");

        Dimension dim_buttons = new Dimension(200, 50);

        play.setPreferredSize(dim_buttons);
        play_p.add(play);
        right_p.add(play_p);

        right_p.add(Box.createRigidArea(new Dimension(0, 0)));   // SPAZIO CHE DIVIDE SLIDER DA BOTTONI

        JPanel stop_p = new JPanel();
        stop_p.setBackground(color);
        JButton stop = new JButton("STOP");

        stop.setPreferredSize(dim_buttons);
        stop_p.add(stop);
        right_p.add(stop_p);
        stop.setVisible(false);


        play.addActionListener(new ActionListener() {
            private boolean once = false;

            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (play.getText().equals("PLAY")) {
                    play.setText("PAUSE");

                    if (!once)
                        once = true;
                    else
                        return;

                    stop.setVisible(true);
                    if (!popolazione_txtfield.getText().equals("")) {
                        popolazione = Integer.parseInt(popolazione_txtfield.getText());
                    }                                                                                            // prende POPOLAZIONE
                    if (!tamp_txtfield.getText().equals("")) {
                        tamp = Integer.parseInt(tamp_txtfield.getText());
                    }                                                                                            // prende TAMP
                    if (!incontri_txtfield.getText().equals("")) {
                        incontri = Integer.parseInt(incontri_txtfield.getText());
                    }                                                                                            // prende INCONTRI
                    final int infettività = inf_slider.getValue();
                    final int sintomaticità = sint_slider.getValue();
                    final int letalità = let_slider.getValue();
                    final int durata = durata_slider.getValue();

                    System.out.println("infettività = " + infettività);
                    System.out.println("sintomaticità = " + sintomaticità);
                    System.out.println("letalità = " + letalità);
                    System.out.println("durata = " + durata);
                    System.out.println("popolazione = " + popolazione);
                    System.out.println("tampone = " + tamp);
                    System.out.println("incontri = " + incontri);
                } else {
                    play.setText("PLAY");
                    //dovrebbe anche bloccare il tempo nel manager
                }
            }
        });

        stop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (play.getText().equals("PAUSE")) {
                    play.setText("PLAY");
                    stop.setVisible(false);
                } else {
                    stop.setVisible(false);
                }
            }
        });

    }

    private JSlider createSlider(String label, JPanel parentPanel, Color color, int minorTick, int majorTick, int maxValue) {
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new GridLayout());
        c.fill = GridBagConstraints.HORIZONTAL;
        parentPanel.add(jPanel);

        JLabel jLabel = new JLabel();
        jLabel.setText(label);
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(0, 0, 0, 0);
        jPanel.add(jLabel, c);

        JSlider jSlider = new JSlider(HORIZONTAL, 0, maxValue, maxValue / 2);
        jSlider.setMinorTickSpacing(minorTick);
        jSlider.setMajorTickSpacing(majorTick);
        jSlider.setPaintTicks(true);
        jSlider.setPaintLabels(true);

        //inf_slider.setBackground(new java.awt.Color(231, 111, 81));
        jSlider.setForeground(color);


        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 1;
        c.insets = new Insets(0, 40, 0, 30);
        jPanel.add(jSlider, c);
        return jSlider;
    }

    private void createCenterPanel(JFrame f, Color background, Color healthy, Color asymptomatic, Color symptomatic, Color healed, Color dead) {

        // CREATE CENTER LAYOUT AS BORDERLAYOUT

        JPanel center = new JPanel();
        center.setLayout(new BorderLayout());
        center.setBackground(background);
        f.add(center, BorderLayout.CENTER);


        // INSERIMENTO PARTE 2D AL CENTRO DEL FRAME
        TwoDPart t = new TwoDPart();
        center.add(t, BorderLayout.CENTER);
        t.initialize();


        // SIZE CHANGING BAR

        JPanel bar = new JPanel();
        bar.setBackground(green);
        bar.setLayout(new GridBagLayout());
        GridBagConstraints s = new GridBagConstraints();
        center.add(bar, BorderLayout.PAGE_END);


        JLabel green_bar = new JLabel();
        green_bar.setText(String.valueOf(t.num_green));
        green_bar.setOpaque(true);
        green_bar.setBackground(healthy);

        s.fill = GridBagConstraints.HORIZONTAL;
        s.gridy = 0;
        s.gridx = 0;
        s.weightx = t.num_green;
        bar.add(green_bar, s);


        JLabel yellow_bar = new JLabel();
        yellow_bar.setText(String.valueOf(t.num_yellow));
        yellow_bar.setOpaque(true);
        yellow_bar.setBackground(asymptomatic);


        s.fill = GridBagConstraints.HORIZONTAL;
        s.gridx = 1;
        s.gridy = 0;
        s.weightx = t.num_yellow;
        bar.add(yellow_bar, s);


        JLabel red_bar = new JLabel();
        red_bar.setText(String.valueOf(t.num_red));
        red_bar.setOpaque(true);
        red_bar.setBackground(symptomatic);


        s.fill = GridBagConstraints.HORIZONTAL;
        s.gridx = 2;
        s.gridy = 0;
        s.weightx = t.num_red;
        bar.add(red_bar, s);


        JLabel dead_bar = new JLabel();
        dead_bar.setText(String.valueOf(t.num_black));
        dead_bar.setOpaque(true);
        dead_bar.setBackground(dead);

        s.fill = GridBagConstraints.HORIZONTAL;
        s.gridx = 3;
        s.gridy = 0;
        s.weightx = t.num_black;
        bar.add(dead_bar, s);


        JLabel blue_bar = new JLabel();
        blue_bar.setText(String.valueOf(t.num_blue));
        blue_bar.setOpaque(true);
        blue_bar.setBackground(healed);


        s.fill = GridBagConstraints.HORIZONTAL;
        s.gridx = 4;
        s.gridy = 0;
        s.weightx = t.num_blue;
        bar.add(blue_bar, s);
    }
}

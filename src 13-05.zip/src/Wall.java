import java.awt.*;

public class Wall {
    private Rectangle rect;
    public Vector2 dir;

    Wall(Point upperLeft, int width, int height, int angle){
        this.rect = new Rectangle(upperLeft.x, upperLeft.y, width, height);
        dir = new Vector2(angle);
    }

    public boolean contains(Point other){
        //System.out.println(rect.getMaxY()+" "+(rect.y+rect.height)+" "+rect.contains(getUpperLeft())+" "+rect.contains(getBottomRight()));
        return rect.contains(other);
    }

    public Point getUpperLeft(){
        return new Point((int)rect.getMinX(), (int)rect.getMaxY());
    }
    public Point getBottomRight(){
        return new Point((int)rect.getMaxX(), (int)rect.getMinY());
    }
}

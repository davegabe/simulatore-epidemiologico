import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;

public class TwoDPart extends JPanel implements Runnable {

    private final Color yellow = new Color(233, 196, 106);
    private final Color green = new Color(42, 157, 143);
    private final Color red = new Color(231, 111, 81);
    private final Color blue = new Color(45, 143, 171);
    private final Color black = new Color(26, 24, 27);
    private final Color gunmetal = new Color(19, 39, 53);
    int num_green = 0;
    int num_yellow = 0;
    int num_red = 0;
    int num_blue = 0;
    int num_black = 0;
    Graphics g;


    public TwoDPart() {
        setSize(960, 960);
        setVisible(true);
    }

    public void initialize(){
        g = new Graphics() {
            @Override
            public Graphics create() {
                return null;
            }

            @Override
            public void translate(int i, int i1) {

            }

            @Override
            public Color getColor() {
                return null;
            }

            @Override
            public void setColor(Color color) {

            }

            @Override
            public void setPaintMode() {

            }

            @Override
            public void setXORMode(Color color) {

            }

            @Override
            public Font getFont() {
                return null;
            }

            @Override
            public void setFont(Font font) {

            }

            @Override
            public FontMetrics getFontMetrics(Font font) {
                return null;
            }

            @Override
            public Rectangle getClipBounds() {
                return null;
            }

            @Override
            public void clipRect(int i, int i1, int i2, int i3) {

            }

            @Override
            public void setClip(int i, int i1, int i2, int i3) {

            }

            @Override
            public Shape getClip() {
                return null;
            }

            @Override
            public void setClip(Shape shape) {

            }

            @Override
            public void copyArea(int i, int i1, int i2, int i3, int i4, int i5) {

            }

            @Override
            public void drawLine(int i, int i1, int i2, int i3) {

            }

            @Override
            public void fillRect(int i, int i1, int i2, int i3) {

            }

            @Override
            public void clearRect(int i, int i1, int i2, int i3) {

            }

            @Override
            public void drawRoundRect(int i, int i1, int i2, int i3, int i4, int i5) {

            }

            @Override
            public void fillRoundRect(int i, int i1, int i2, int i3, int i4, int i5) {

            }

            @Override
            public void drawOval(int i, int i1, int i2, int i3) {

            }

            @Override
            public void fillOval(int i, int i1, int i2, int i3) {

            }

            @Override
            public void drawArc(int i, int i1, int i2, int i3, int i4, int i5) {

            }

            @Override
            public void fillArc(int i, int i1, int i2, int i3, int i4, int i5) {

            }

            @Override
            public void drawPolyline(int[] ints, int[] ints1, int i) {

            }

            @Override
            public void drawPolygon(int[] ints, int[] ints1, int i) {

            }

            @Override
            public void fillPolygon(int[] ints, int[] ints1, int i) {

            }

            @Override
            public void drawString(String s, int i, int i1) {

            }

            @Override
            public void drawString(AttributedCharacterIterator attributedCharacterIterator, int i, int i1) {

            }

            @Override
            public boolean drawImage(Image image, int i, int i1, ImageObserver imageObserver) {
                return false;
            }

            @Override
            public boolean drawImage(Image image, int i, int i1, int i2, int i3, ImageObserver imageObserver) {
                return false;
            }

            @Override
            public boolean drawImage(Image image, int i, int i1, Color color, ImageObserver imageObserver) {
                return false;
            }

            @Override
            public boolean drawImage(Image image, int i, int i1, int i2, int i3, Color color, ImageObserver imageObserver) {
                return false;
            }

            @Override
            public boolean drawImage(Image image, int i, int i1, int i2, int i3, int i4, int i5, int i6, int i7, ImageObserver imageObserver) {
                return false;
            }

            @Override
            public boolean drawImage(Image image, int i, int i1, int i2, int i3, int i4, int i5, int i6, int i7, Color color, ImageObserver imageObserver) {
                return false;
            }

            @Override
            public void dispose() {

            }
        };
        paintComponent(g);
        Thread thread = new Thread(this);
        thread.start();
    }

    public void run(){
        while(true){
            try {
                Thread.sleep(100);
            } catch (Exception e){ }
            repaint();
        }
    }

    public void paintComponent(Graphics g) {
        /*if (tizio.condition==Person.status.yellow){ g.setColor(yellow); }
        else if (tizio.condition==Person.status.green){ g.setColor(green); }
        else if (tizio.condition==Person.status.red){ g.setColor(red); }
        else if (tizio.condition==Person.status.blue){ g.setColor(blue); }
        else if (tizio.condition==Person.status.black){ g.setColor(black); }
        g.fillOval(Person.x, Person.y,35,35);*/
        g.setColor(gunmetal);
        g.fillRect(0,0,9000,9000);

        g.setColor(green);
        num_green++;
        g.fillOval(500, 500, 35, 35);
    }
}

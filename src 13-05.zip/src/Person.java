import java.util.HashMap;

public class Person {
    enum status {green, yellow, blue, red, black}
    static int r = 3;
    status condition;
    boolean hasVirus;
    boolean mobility;
    HashMap contacts;
    int x;                                      //x, y -> person's position  in the space
    int y;
    int infectedDays;
    int symptomsDay;

    public void meeting(Person person) {
    }

    public void turningYellow() {
        condition = status.yellow;
    }

    public void turningBlue() {
        condition = status.blue;
    }

    public void turningRed() {
        condition = status.red;
    }

    public void turningBlack() {
        condition = status.black;
    }


}

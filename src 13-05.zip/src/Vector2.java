public class Vector2 {
    public int angle;

    enum a{b}
    a c = Vector2.a.b;
    Vector2(int angle){
        this.angle=angle;
        fixAngle();
    }

    public void randomDirection(int otherAngle){
        angle = (int)Math.floor(otherAngle+Math.random()*90-45);
        fixAngle();
    }

    private void fixAngle(){
        if(angle<0){
            angle=360+angle;
        } else {
            angle=angle%360;
        }
    }

    public int getInvertedAngle() {
        return (angle+180)%360;
    }
}

import java.util.ArrayList;

public class QuadTree {
    public QuadTree[] children;
    private int x1, x2, y1, y2;
    public ArrayList<Person> people = new ArrayList<>();

    QuadTree(int x1, int x2, int y1, int y2){
        this.x1=x1;
        this.x2=x2;
        this.y1=y1;
        this.y2=y2;
    }

    private void split(){
        int midx = x1+(x2-x1)/2;
        int midy = y1+(y2-y1)/2;
        if(children==null) {
            children = new QuadTree[4];
            children[0] = new QuadTree(x1, midx, y1, midy);
            children[1] = new QuadTree(midx, x2, y1, midy);
            children[2] = new QuadTree(x1, midx, midy, y2);
            children[3] = new QuadTree(midx, x2, midy, y2);
        }
        for (int i = 0; i < people.size(); i++) {
            int distanceFromMidX = Math.abs(people.get(i).x-midx);
            int distanceFromMidY = Math.abs(people.get(i).y-midy);
            //insert the player in the correct sub-quadtree but if it overlaps two or more sub-quadtrees, it will be inserted in each of them
            if (people.get(i).x<midx || distanceFromMidX<= Person.r){
                if (people.get(i).y<midy || distanceFromMidY<= Person.r) {
                    children[0].insert(people.get(i));
                }
                if (people.get(i).y>=midy || distanceFromMidY<= Person.r) {
                    children[2].insert(people.get(i));
                }
            }
            if (people.get(i).x>=midx || distanceFromMidX<= Person.r){
                if (people.get(i).y<midy || distanceFromMidY<= Person.r) {
                    children[1].insert(people.get(i));
                }
                if (people.get(i).y>=midy || distanceFromMidY<= Person.r) {
                    children[3].insert(people.get(i));
                }
            }
        }
        people.clear();
    }

    public void insert(Person person){
        people.add(person);
        if ((people.size() >= 3 || children!=null)&&(x2-x1> Person.r && y2-y1> Person.r)) {  //if there are too many players or is not a leaf and the division is bigger than the Player dimension, move them deeper
            split();
        }
    }
}
import java.awt.*;

public class Physics {
    int x1,x2,y1,y2;
    Manager manager;

    Physics(Manager manager,int x1, int x2, int y1, int y2) {   //constructor bellino da fare senza gli zeri
        this.manager=manager;
        this.x1=x1;
        this.x2=x2;
        this.y1=y1;
        this.y2=y2;
    }

    public void update(){
        //create the quadTree
        QuadTree quadTree = new QuadTree(x1,x2,y1,y2);
        for (int i = 0; i < manager.people.length; i++) {
            quadTree.insert(manager.people[i]);
        }
        //
        findNearPlayers(quadTree);
        movePlayers();
    }

    private void movePlayers(){
        for (int i = 0; i < manager.people.length ; i++) {
            manager.people[i].move();
        }
    }

    private void findNearPlayers(QuadTree quadtree){
        if (quadtree.children==null){   //if is a leaf check collisions
            checkCollision();
        } else {
            for (int i = 0; i < 4; i++) {   //if isn't a leaf, go deeper
                findNearPlayers(quadtree.children[i]);
            }
        }
    }

    private void checkCollision(){
        for (int i = 0; i < manager.people.length ; i++) {
            //check with other players
            for (int j = i+1; j < manager.people.length ; j++) {
                manager.people[i].move();
                double distance = Math.sqrt( Math.pow(manager.people[i].x - manager.people[j].x, 2) +Math.pow(manager.people[i].y- manager.people[j].y,2));
                manager.people[i].moveBack();
                if(distance<= Person.r*2){
                    manager.people[i].meeting(manager.people[j]);
                    manager.people[j].meeting(manager.people[i]);

                    double invertedAnglei = manager.people[i].dir.getInvertedAngle();
                    double invertedAnglej = manager.people[j].dir.getInvertedAngle();
                    manager.people[i].dir.randomDirection(invertedAnglej);
                    manager.people[j].dir.randomDirection(invertedAnglei);
                }
            }
            //check with walls
            for (int j = 0; j < 4; j++) {
                manager.people[i].move();
                Point upper = new Point(manager.people[i].x, manager.people[i].y- Person.r);
                Point bottom = new Point(manager.people[i].x, manager.people[i].y+ Person.r);
                Point left = new Point(manager.people[i].x- Person.r, manager.people[i].y);
                Point right = new Point(manager.people[i].x+ Person.r, manager.people[i].y);
                manager.people[i].moveBack();
                if(manager.walls[j].contains(upper)||manager.walls[j].contains(bottom)||manager.walls[j].contains(left)||manager.walls[j].contains(right)){
                    manager.people[i].dir.randomDirection(manager.walls[j].dir.angle);
                }
            }
        }
    }

}

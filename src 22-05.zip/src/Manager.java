public class Manager {
    public int duration;
    public int infectivity;
    public int symptomaticity;
    private int resources;
    private float swabCost;
    private float speed;
    public Person[] people;
    public Wall[] walls;
    public Physics physics;
    public TwoDPart twoDPart;

    public static void main(String[] args) {
        new Manager().initialize();
    }

    public void initialize(){
        int nPeople = 4;
        people = new Person[nPeople];
        for (int i = 0; i < nPeople; i++) {
            people[i]= new Person((int) (Math.random()*657)+10, (int)(Math.random()*730)+10, this);
        }
        twoDPart = new TwoDPart(this);
        int maxBox=twoDPart.getWidth();
        walls = new Wall[4];
        walls[0] = new Wall( 0,0, maxBox,10,270);//top
        walls[1] = new Wall( 0,0, 10, maxBox, 0);//left
        walls[2] = new Wall( maxBox,0, 10,maxBox,180);//right
        walls[3] = new Wall( 0,maxBox, maxBox,10,90);//bottom
        physics = new Physics(this, 0,maxBox,0, maxBox);
        GUI gui = new GUI(this);
        gui.initialize();
        twoDPart.initialize();
    }

    public void changeSpeed(int tick){
        twoDPart.setTick(tick);
    }
}

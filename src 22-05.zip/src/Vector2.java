public class Vector2 {
    public double angle;

    Vector2(double angle){
        this.angle=angle;
        fixAngle();
    }

    Vector2(){
        this.angle=Math.random()*355;
        fixAngle();
    }

    public void randomDirection(double otherAngle){
        double newReflection = Math.toRadians(Math.random()*90);
        angle = otherAngle+newReflection-newReflection/2;
    }

    private void fixAngle(){
        angle=Math.toRadians(angle);
    }

    public double getInvertedAngle() {
        return Math.toRadians(angle+180);
    }
}

public class Vector2 {
    static final int speed = Person.r/5;
    public int speedX;
    public int speedY;

    Vector2(int speedX, int speedY){
        this.speedX=speedX*speed;
        this.speedY=speedY*speed;
    }

    Vector2(){
        do {
            this.speedX = (int) (Math.random() * speed) - (speed / 2);
            this.speedY = (int) (Math.random() * speed) - (speed / 2);
        } while(speedY==speedX && speedY==0);

        //this.speedX=(1-2*(int)Math.round(Math.random())-(int)Math.round(Math.random()))*speed;
        //this.speedY=(1-2*(int)Math.round(Math.random())-(int)Math.round(Math.random()))*speed;
    }

}

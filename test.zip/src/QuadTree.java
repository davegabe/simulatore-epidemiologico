import java.util.ArrayList;

public class QuadTree {
    public QuadTree[] children;
    private final int maxSize=1000;
    private int x1, x2, y1, y2;
    public ArrayList<Person> people = new ArrayList<>();

    QuadTree(int x1, int x2, int y1, int y2){
        this.x1=x1;
        this.x2=x2;
        this.y1=y1;
        this.y2=y2;
    }

    public void clear() {
        people.clear();

        if (children==null)
            return;
        for (int i = 0; i < children.length; i++) {
            if (children[i] != null) {
                children[i].clear();
                children[i] = null;
            }
        }
    }

    private int getIndex(Person person) {
        int index = -1;
        int midx = x1+(x2-x1)/2;
        int midy = y1+(y2-y1)/2;

        boolean topQuadrant = (person.y < midx && person.y + person.r < midx);  // if it's in the upper half
        boolean bottomQuadrant = (person.y > midx);                             // if it's in the bottom half

        if (person.x < midy && person.x + person.r < midy) {                    //if it's in the left half
            if (topQuadrant) {
                index = 1;
            }
            else if (bottomQuadrant) {
                index = 2;
            }
        } else if (person.x > midy) {                                           //if it's in the right half
            if (topQuadrant) {
                index = 0;
            }
            else if (bottomQuadrant) {
                index = 3;
            }
        }

        return index;
    }

    public ArrayList<Person> retrieve(ArrayList<Person> returnObjects, Person person) {
        int index = getIndex(person);
        if (index != -1 && children != null) {
            children[index].retrieve(returnObjects, person);
        }

        returnObjects.addAll(people);

        return returnObjects;
    }

    private void split(){
        int midx = x1+(x2-x1)/2;
        int midy = y1+(y2-y1)/2;
        if(children==null) {
            children = new QuadTree[4];
            children[0] = new QuadTree(x1, midx, y1, midy);
            children[1] = new QuadTree(midx, x2, y1, midy);
            children[2] = new QuadTree(x1, midx, midy, y2);
            children[3] = new QuadTree(midx, x2, midy, y2);
        }
    }

    public void insert(Person person){
        if (children != null) {
            int index = getIndex(person);
            if (index != -1) {
                children[index].insert(person);
                return;
            }
        }

        people.add(person);

        if ((people.size() >= maxSize-2 || children!=null)&&(x2-x1> Person.r && y2-y1> Person.r)) {  //if there are too many players or is not a leaf and the division is bigger than the Player dimension, move them deeper
            if (children == null) {
                split();
            }

            int i = 0;
            while (i < people.size()) {
                int index = getIndex(people.get(i));
                if (index != -1) {
                    children[index].insert(people.remove(i));
                }
                else {
                    i++;
                }
            }
        }
    }
}